"""
Demo application used by example custom plugins that builds upon demo_app nut has HTTP basic auth
enabled by default.
"""

import sys
import plugin_sdk.demo_app

if __name__ == '__main__':
    plugin_sdk.demo_app.main(sys.argv[1:], default_auth=True, default_port=8090)
