import sys
import os
import logging

log = logging.getLogger(__name__)


def get_default_installation_dir():
    """
    Returns default installation directory for Osagent. It should return
    C:/ProgramFiles(x86)/dynatrace/oneagent for Windows and /opt/dynatrace/oneagent for Linux

    :rtype: str
    :return: remote plugin agent installation directory
    """
    if sys.platform == "win32":
        ret = get_dir_from_registry(
            "SYSTEM\\CurrentControlSet\\Services\\oneagentmon\\Parameters"
        )
        if ret is None:
            ret = get_dir_from_registry(
                "SYSTEM\\CurrentControlSet\\Services\\osagentmon\\Parameters"
            )
            if ret is None:
                ret = get_dir_from_registry(
                    "SYSTEM\\CurrentControlSet\\Services\\RUXITMon\\Parameters"
                )
            if ret is None:
                ret = os.getcwd()
    else:
        ret = os.path.join(os.path.sep, "opt", "dynatrace", "oneagent")
        if not os.path.isdir(ret):
            ret = os.getcwd()
    logging.debug("Setting installation root dir to %s", ret)
    return ret


def get_default_config_persistence_dir():
    """
    Returns default config persistence for Osagent where all files created by agent will be stored. It
    should return C:/ProgramData/dynatrace/oneagent/agent/conf for Windows and
    /opt/dynatrace/oneagent/agent/conf for Linux

    :rtype: str
    :return: remote plugin agent storage directory
    """
    if sys.platform == "win32":
        ret = os.path.join(os.environ["programdata"], "dynatrace", "oneagent", "agent", "config")
    else:
        ret = os.path.join(os.path.sep, "var","lib","dynatrace","oneagent","agent","config")
    logging.debug("Setting persistence config dir to %s", ret)
    return ret


def get_dir_from_registry(reg_path):
    """
    Returns installation directory read from Osagent Registry on Windows. This function reads 'LogDirectory' value
    from Osagent registry

    :rtype: str
    :return: remote plugin agent installation directory
    """
    import winreg

    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, reg_path) as k:
            log_path = winreg.QueryValueEx(k, "PAPath32")
            return os.path.abspath(
                os.path.join(
                    log_path[0], os.path.pardir, os.path.pardir, os.path.pardir, os.path.pardir, os.path.pardir
                )
            )
    except:
        log.debug(
            "Could not read installation directory from registry key %s, falling back to default, details:",
            reg_path,
            exc_info=1,
        )
    return None
