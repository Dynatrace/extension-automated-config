"""
Demo application used by example custom plugins.
It is a bottle app consisting of one stats view, and a few command-line options for changing
parameters like port, auth credentials etc.

You can learn more about parameters by running the --help command
"""
import bottle
import random
import argparse
import sys
import plugin_sdk
import math
import json

__version__ = plugin_sdk.__version__

ui_metrics_enabled = False


class Stats():
    """
    Main app logic returns two stats - an ever increasing counter and a random number.
    """

    def __init__(self):
        self._counter = 0

    def get(self):
        self._counter += 1
        battery_level = 100 - self._counter/10
        return {
            'version': '1.001',
            'random': random.randint(1, 1000),
            'counter': self._counter,
            'state': random.choice(['OK', 'WARNING', 'ERROR']),
            'stat_counter': [10 - random.randint(1, 5), 10, 10 + random.randint(1, 5)],
            'battery_level': battery_level if battery_level > 0 else 0
        }

    def get_ui_stats(self):
        self._counter += 1
        randbar = random.randint(1, 3)
        rand1 = random.randint(50, 150)
        rand2 = random.randint(50, 150)
        rand3 = random.randint(50, 150)
        return {
            'randbar_red': 3 if randbar == 3 else 0,
            'randbar_yellow': 2 if randbar == 2 else 0,
            'randbar_green': 1 if randbar == 1 else 0,
            'rand_stacked1': rand1,
            'rand_stacked2': rand1 + rand2,
            'rand_stacked3': rand1 + rand2 + rand3,
            'sin_small_noise': math.sin(self._counter * math.pi / 12) * 500 + 1000 + random.randint(-5, 5),
            'sin_big_noise': math.sin(self._counter * math.pi / 12) * 500 + 1000 + random.randint(-50, 50),
            'sin_rounded': math.floor(math.sin(self._counter * math.pi / 12) * 10 + 10.5)
        }


stat0 = Stats()
stat1 = Stats()
stat2 = Stats()


def make_auth_check(expected_user, expected_password):
    def auth_check(user, password):
        return user.strip() == expected_user and password.strip() == expected_password

    return auth_check


def stats():
    global ui_metrics_enabled
    stats = dict(stat0.get())
    if ui_metrics_enabled:
        for key, value in (stat0.get_ui_stats()).items():
            if key not in stats:
                stats[key] = value
    return stats


def topology():
    topology = []
    device1 = {'name': 'My Device 01', 'ip': '192.168.0.1', 'stats': stat1.get()}
    device2 = {'name': 'My Device 02', 'ip': '127.0.0.1', 'stats': stat2.get()}
    group = {'name': 'My Group 01', 'devices': [device1, device2]}
    topology.append(group)
    return json.dumps(topology)


def deployment_status():
    return "Demo deployment status page."


def deployment_remediation():
    return "Not need to do anything. It is just a demo."


class RegisterCalledAction(argparse._StoreAction):
    called = False

    def __call__(self, parser, namespace, values, option_string=None):
        self.called = True
        return super().__call__(parser, namespace, values, option_string)


def create_args_parser(default_auth=False, default_port=8769, default_ui=False):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--auth',
        action='store_true',
        default=default_auth,
        help='Protect stats page with HTTP basic auth'
    )
    parser.add_argument(
        '--ui',
        action='store_true',
        default=default_ui,
        help='Generate additional metrics for UI demo'
    )
    parser.add_argument(
        '-p', '--port',
        action='store',
        default=default_port,
        type=int,
        nargs='?',
        help='Port of the demo application [default %s]' % default_port
    )
    user_action = parser.add_argument(
        '--user',
        action=RegisterCalledAction,
        default='ruxit',
        type=str,
        nargs='?',
        help='Username for authentication (implies auth)'
    )
    password_action = parser.add_argument(
        '--password',
        action=RegisterCalledAction,
        default='ruxit',
        type=str,
        nargs='?',
        help='Password for authentication (implies auth)'
    )
    parser.add_argument(
        '--version',
        action="version",
        help="show program's version and exit",
        version=('{name} {version}'.format(name=__loader__.name, version=__version__))
    )
    return parser, password_action, user_action


def main(cmd_args, default_auth=False, default_port=8769, default_ui=False):
    """
    Main method of demo app - parses command line arguments and starts bottle app.
    """
    parser, password_action, user_action = create_args_parser(default_auth=default_auth, default_port=default_port,
                                                              default_ui=default_ui)
    args = parser.parse_args(cmd_args)
    global stats
    global topology
    global deployment_status
    global deployment_remediation
    global ui_metrics_enabled
    ui_metrics_enabled = args.ui
    if args.auth or user_action.called or password_action.called:
        auth_check = make_auth_check(args.user, args.password)
        stats = bottle.route('/')(
            bottle.auth_basic(auth_check, realm="user: %s, password: %s" % (args.user, args.password))(stats)
        )
        topology = bottle.route('/topology')(
            bottle.auth_basic(auth_check, realm="user: %s, password: %s" % (args.user, args.password))(topology)
        )
        deployment_status = bottle.route('/deployment')(
            bottle.auth_basic(auth_check, realm="user: %s, password: %s" % (args.user, args.password))(
                deployment_status)
        )
        deployment_status = bottle.route('/remediation')(
            bottle.auth_basic(auth_check, realm="user: %s, password: %s" % (args.user, args.password))(
                deployment_remediation)
        )
    else:
        stats = bottle.route('/')(stats)
        topology = bottle.route('/topology')(topology)
        deployment_status = bottle.route('/deployment')(deployment_status)
        deployment_status = bottle.route('/remediation')(deployment_remediation)
    bottle.run(host='0.0.0.0', port=args.port)


if __name__ == '__main__':
    main(sys.argv[1:])
