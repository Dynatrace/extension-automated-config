import argparse
import contextlib
import logging
import os
import setuptools
import shutil
import sys
import tempfile
import subprocess
import stat
from pathlib import Path
import plugin_sdk.sdk_version
import plugin_sdk.plugin_upload
from plugin_sdk.default_dir_provider import DefaultDirProvider
from plugin_sdk import validator
from .python_check import python_version_compatible
from urllib.parse import urlparse, urlunparse, urljoin

logging.basicConfig(stream=sys.stderr, format="%(message)s", level=logging.INFO)
log = logging.getLogger(__package__)
OLD_FILES_BLOCKLIST_FILE = "file_blacklist.txt"
FILES_BLOCKLIST_FILE = "file_blocklist.txt"


@contextlib.contextmanager
def work_in_dir(path):
    _cwd = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        log.info("Leaving directory %s", path)
        os.chdir(_cwd)


def main():
    if not python_version_compatible():
        exit(1)
    parsed_args = None
    try:
        parsed_args = _parse_args(sys.argv[1:])
        _main(parsed_args)
    except Exception as ex:
        log.error("Error occured: %s", ex)
        if parsed_args and parsed_args.verbose:
            log.exception("Error details:")
        sys.exit(1)


def _validate_plugin_json(json_path):
    return validator._validate_plugin_json(json_path)


def _main(args):
    log.info("Starting oneagent_build_plugin")
    source_dir = os.path.abspath(args.plugin_dir)
    plugin_json_path = os.path.join(source_dir, "plugin.json")
    meta = _validate_plugin_json(plugin_json_path)
    plugin_name = meta.plugin_name
    remote = plugin_sdk.plugin_upload.is_remote(plugin_name)
    dir_provider = DefaultDirProvider(remote)
    log.info("Plugin data: %s", meta)

    target_root = (
        dir_provider.get_default_target_root()
        if not args.deployment_dir
        else args.deployment_dir
    )
    target_dir = os.path.abspath(os.path.join(target_root, plugin_name))
    if os.path.abspath(source_dir) == os.path.abspath(target_dir):
        raise Exception("Source and target dir are the same, aborting")

    with tempfile.TemporaryDirectory() as tmp_wheeldir, tempfile.TemporaryDirectory() as tmp_installpath:
        produced_dist, egg_info_path = _create_plugin_wheel(meta, source_dir, tmp_wheeldir)
        log.info("Created distribution of the plugin: %s" % produced_dist.dist_files)
        
        if os.path.exists(target_dir):
            shutil.rmtree(target_dir)

        log.info("Installing plugin to temporary location")
        whlpath = produced_dist.dist_files[0][2]
        _install_plugin_wheel(tmp_installpath, os.path.join(tmp_wheeldir, whlpath))
        
        log.info("Copying plugin to target_directory: %s" % target_dir)
        if os.path.exists(egg_info_path):
          shutil.rmtree(egg_info_path)
        _copy_plugin(tmp_installpath, source_dir, target_dir)
        log.info("Creating plugin archive")
        archive_basename = os.path.join(target_root, plugin_name)
        archive_name = shutil.make_archive(
            archive_basename, "zip", root_dir=target_root, base_dir=plugin_name
        )

        log.info("=" * 40)
        log.info("Plugin deployed successfully into %s", target_dir)
        log.info("Plugin archive available at %s", archive_name)
        log.info("=" * 40)
    if args.no_upload:
        return
    upload_plugin_zip(archive_name, args.no_cert_ver, remote, args.token, args.token_file, args.server)

def validate_server_url(url, remote):
    url_extended = ""
    endpoint_path = "api/v1/remoteplugins" if remote else "api/v1/plugins"
    parse_url = urlparse(url)
    if all([parse_url.scheme, parse_url.netloc]):
        url_extended = urlunparse([parse_url.scheme, parse_url.netloc, urljoin(parse_url.path+'/', endpoint_path), '', '', ''])
        return url_extended
    else:
        return ""

def upload_plugin_zip(archive_name, no_cert_ver, remote, token_=None, token_file_=None, server_=None):
    servers = plugin_sdk.plugin_upload.get_server_names(remote, server_)
    if not servers:
        address = input("Enter server address, exemplary address: https://demo.dev.dynatracelabs.com, or for managed include the tenant ID in the path: https://latest.managed-dev.dynalabs.io/e/5c6cf54c-5fe3-47e8-af18-54439090370b:")
        address = validate_server_url(address, remote)
        if address:
            servers.append(address)
        else:
            log.info("Incorrect server address, exemplary address: https://demo.dev.dynatracelabs.com")
            exit(-1)
    try:
        token = plugin_sdk.plugin_upload.get_token(remote, token_, token_file_)
    except:
        token = None
    if token is None:
        token_param = _get_token_input()
    else:
        token_param = ("-t", token)
    for server in servers:
        if no_cert_ver:
            upload_command = "oneagent_upload_plugin -p {0} -s {1} {2} {3} --no_cert_ver".format(
                archive_name, server, token_param[0], "#" * len(token_param[1])
            )
        else:
            upload_command = "oneagent_upload_plugin -p {0} -s {1} {2} {3}".format(
                archive_name, server, token_param[0], "#" * len(token_param[1])
            )
        log.info("interactive upload -> %s" % upload_command)
        token_file = None
        token = None
        if token_param[0] == "-t":
            token = token_param[1]
        else:
            token_file = token_param[1]
        upload_status = plugin_sdk.plugin_upload.main_body(
            archive_name, server, token, token_file, no_cert_ver
        )
        if upload_status:
            break


def upload_entrypoint(args):
    archive_file_name = os.path.splitext(os.path.basename(args.s))[0]
    upload_plugin_zip(args.s, "no_cert_ver" in args, plugin_sdk.plugin_upload.is_remote(archive_file_name), args.token, args.token_file, args.server)


def _get_token_input():
    is_token_file = input("Does token file exist? (Y or N; default is Y): ")
    if len(is_token_file) > 0 and is_token_file in {"n", "N"}:
        return ("-t", input("Enter authentication token: "))
    else:
        return ("-T", input("Enter token file path : "))

def _get_dir_provider(remote):
    dir_provider = DefaultDirProvider(remote)
    return dir_provider

def _parse_args(cmd_args):
    parser = argparse.ArgumentParser()
    parser.add_argument("-p", "--plugin_dir", help="plugin source directory", default=os.getcwd())
    parser.add_argument("-d", "--deployment_dir", help="destination dir to deploy plugin")
    parser.add_argument(
        "-v", "--verbose", help="increase verbosity", action="store_true"
    )
    parser.add_argument(
        "--no_upload", action="store_true", help="turn off upload to the server"
    )
    parser.add_argument(
        "--no_cert_ver",
        help="turn off ssl certificate verification",
        action="store_true",
    )
    parser.add_argument(
        "-s",
        "--server",
        help="server address (taken from oneagent configuration file by default)",
    )
    parser.add_argument(
        "-t",
        "--token",
        help="set the authentication token (token file is used if token is not set)",
    )
    rem_path = _get_dir_provider(True).get_default_conf_dir()
    local_path = _get_dir_provider(False).get_default_conf_dir()
    parser.add_argument(
        "-T",
        "--token_file",
        help="set the authentication token file (by default env variable ONEAGENT_PLUGIN_UPLOAD_TOKEN, "
             "or plugin_upload.token from configuration directory, "
            f"which is: {rem_path} for remote plugin or: {local_path} for local plugin,"
            "if env variable is not specified)",
    )

    __version__ = plugin_sdk.sdk_version.get_version()
    parser.add_argument(
        "--version",
        action="version",
        help="show program's version and exit",
        version=("{name} {version}".format(name=__package__, version=__version__)),
    )
    args = parser.parse_args(cmd_args)
    log.info("Arguments=%s", args)
    if args.verbose:
        log.setLevel(logging.DEBUG)
    return args


def _create_plugin_wheel(meta, source_dir, work_dir):
    try:
        log.info("Cleaning up previous build information")
        egg_info_path = os.path.join(source_dir, "%s.egg-info" % meta.package_name)
        if os.path.exists(egg_info_path):
            shutil.rmtree(egg_info_path)

        with work_in_dir(work_dir):
            produced_dist = setuptools.setup(
                name=meta.package_name,
                version=meta.plugin_version,
                package_dir={"": source_dir},
                py_modules=meta.pymodules,
                packages=meta.packages,
                package_data=meta.package_data,
                install_requires=meta.install_requires,
                script_args=["bdist_wheel"],
            )

        if produced_dist is None:
            raise Exception("Failed to create a distribution of the plugin")
    except SystemExit as ex:
        raise Exception(
            "Error when creating wheel package from plugin, details: %s" % ex
        ) from ex
    return produced_dist, egg_info_path


def _install_plugin_wheel(tmp_installpath, whlpath):
    import subprocess

    try:
        subprocess.check_call(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "--ignore-installed",
                "--only-binary=:none:",
                "--disable-pip-version-check",
                "--target=" + tmp_installpath,
                "--upgrade",
                "--no-compile",
                whlpath,
            ],
            timeout=60,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        print("Failed to install the plugin into temporary location")
        exit(-1)

#original shutil.copytree doesn't copy into existing folder
#copytree_fixed doesn't create destination one
def copytree_fixed(src, dst, symlinks=False, ignore=None):
    dir_list = os.listdir(src)
    if ignore:
       ignore_names = ignore(src, dir_list)
    else:
       ignore_names = {}
    
    for item in dir_list:
        if item in ignore_names:
           continue
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            shutil.copytree(s, d, symlinks, ignore)
        else:
            shutil.copy2(s, d)
            
def _copy_plugin(install_path, source_dir, target_dir):
    source = Path(os.path.abspath(source_dir))
    target = Path(os.path.abspath(target_dir))
    sdk_path = os.path.dirname(os.path.abspath(__file__))
    _ignore = \
        _parse_ignore_file(os.path.join(sdk_path, FILES_BLOCKLIST_FILE)) | \
        _parse_ignore_file(os.path.join(source, FILES_BLOCKLIST_FILE)) | \
        _parse_ignore_file(os.path.join(sdk_path, OLD_FILES_BLOCKLIST_FILE)) | \
        _parse_ignore_file(os.path.join(source, OLD_FILES_BLOCKLIST_FILE))
    shutil.copytree(install_path, target_dir, ignore=shutil.ignore_patterns(*_ignore))
    if source in target.parents:
        relative = target.relative_to(source)
        _ignore.add('.*')
        _ignore.add(relative.parts[0])
    else:
        _ignore.add('.*')
    copytree_fixed(source_dir, target_dir, ignore=shutil.ignore_patterns(*_ignore))
    if sys.platform.startswith("linux"):
        os.chmod(target_dir, 0o775)
        for base, dirs, files in os.walk(target_dir):
            for _dir in dirs:
                log.info(os.path.join(base, _dir))
                os.chmod(os.path.join(base, _dir), 0o775)
            for file in files:
                target_file = os.path.join(base, file)
                rel_path = os.path.relpath(target_file, target_dir)
                base_file_path = os.path.join(source_dir, rel_path)
                is_base_file = os.path.exists(base_file_path)
                is_executable = False
                if is_base_file:
                    base_file_stat = os.stat(base_file_path)
                    is_executable = bool(base_file_stat.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH))
                log.info(os.path.join(base, file))
                if is_executable:
                    os.chmod(target_file, 0o775)
                else:
                    os.chmod(target_file, 0o664)


def _parse_ignore_file(file_name):
    content = set()
    if os.path.isfile(file_name):
        with open(file_name) as f:
            for line in f:
                line = line.strip()
                if not line.startswith("#"):
                    content.add(str(line))
    return content

if __name__ == "__main__":
    main()
