import os
import logging

from plugin_sdk import osagent_default_dirs, rpa_default_dirs

log = logging.getLogger(__name__)


class DefaultDirProvider:
    def __init__(self, remote: bool):
        self.component = rpa_default_dirs if remote else osagent_default_dirs

    def get_default_target_root(self):
        """
        Returns directory where plugins zip should be stored

        :rtype: str
        :return: plugin_development directory
        """
        plugin_folder_name = "plugin_deployment"
        
        ret = os.path.join(
            self.component.get_default_installation_dir(), plugin_folder_name
        )
        logging.debug("Setting target root dir to %s", ret)
        return ret

    def get_default_conf_dir(self):
        """
        Returns configuration directory which is placed at installation folder.
        C:/ProgramFiles on Windows or /opt/ on Linux

        :rtype: str
        :return: config directory placed inside installation directory
        """
        ret = os.path.join(
            self.component.get_default_installation_dir(), "agent", "conf"
        )
        logging.debug("Setting configuration root dir to %s", ret)
        return ret

    def get_default_config_persistence_dir(self):
        """
        Returns default config persistence where all files created by agent will be stored. It
        should return directory with C:/ProgramData or /var/lib/ at the beginning (Win/Linux)

        :rtype: str
        :return: agent config directory
        """
        return self.component.get_default_config_persistence_dir()

    def get_default_active_conf_dir(self):
        """
        Available only for RemotePlugin.
        Returns default config persistence for ActiveGate where target tenant adress can be found. It
        should return C:/ProgramData/dynatrace/gateway/config for Windows and
        /var/lib/dynatrace/gateway/config for Linux

        :rtype: str
        :return: ActiveGate storage directory
        """
        return self.component.get_default_active_conf_dir()
