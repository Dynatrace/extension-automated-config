import abc
import typing
from ruxit.api.results_builder import ResultsBuilder  


class DataReporter(abc.ABC):
    @abc.abstractmethod
    def report_data(self)->None:
        pass
    
    #called after query end to reset status data
    @abc.abstractmethod
    def report_reset(self)->None:
        pass
     
    
class RemoteResultsBuilder(ResultsBuilder):

    MAX_METRIC_SIZE = 100
    
    def __init__(self, data_reporter: DataReporter, logger, external_api, topx_data: typing.Dict[str, int] = {}):
        super().__init__(logger, external_api, topx_data)
        self._reporter = data_reporter
 
    def reset_result(self)->None:
        super().reset_result()
        
    def _check_data(self)->None:
        current_size = self.relative_top_results.size + self.per_second_top_results.size + self.absolute_top_results.size
        if current_size >= RemoteResultsBuilder.MAX_METRIC_SIZE:
            self._reporter.report_data()
        
    def add_relative_result(self, *args, **kwargs)->None:
        super().add_relative_result(*args, **kwargs)
        self._check_data()
        
    def add_absolute_result(self, *args, **kwargs)->None:
        super().add_absolute_result(*args, **kwargs)
        self._check_data()
        
    def add_per_second_result(self, *args, **kwargs)->None:
        super().add_per_second_result(*args, **kwargs)
        self._check_data()

    def partial_flush(self):
        return_data = super().flush_result(is_full=False)
        return return_data

    def flush_result(self):
        return_data = super().flush_result()
        self._reporter.report_reset()
        return return_data