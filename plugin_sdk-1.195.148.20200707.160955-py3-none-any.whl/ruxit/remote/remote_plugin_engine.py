import logging
from ruxit.api.topology_builder import TopologyBuilder, Topology
from ruxit.plugin_state_machine import PluginEngine
from ruxit.plugin_status_reporter import PluginState
from .remote_result_builder import RemoteResultsBuilder
from .remote_data_reporter import RemoteDataReporter


class RemotePluginEngine(PluginEngine):

    def __init__(self, *, remote_api, external_api, entity_resolver, plugin_info, activation_context):
        super().__init__(
            external_api=external_api,
            entity_resolver=entity_resolver,
            plugin_info=plugin_info,
            activation_context=activation_context
        )
        print(self.activation_context)
        self._remote_api = remote_api 
        self.config_id = activation_context.value
        self.endpoint_name = activation_context.endpoint_name
        self.device_counter = 0
        self.group_counter = 0
        self.results_builder = RemoteResultsBuilder(RemoteDataReporter(self), self.logger, external_api, plugin_info.topx_data)
        tenant_id = self.external_api.get_working_tenant()
        self.topology_builder = TopologyBuilder(
            self.config_id, plugin_info.name, tenant_id, plugin_info.technologies_case_sensitive, self.results_builder)
        

    def flush_topology(self) -> Topology:
        """
        Polls the topology from the topology builder
        Return:
            Topology data.
        """
        return self.topology_builder.flush_result() if self.topology_builder else None

    def generate_plugin_args(self):
        plugin_args = super().generate_plugin_args()
        plugin_args['topology_builder'] = self.topology_builder
        return plugin_args

    def set_full_status(self, state:PluginState, exception_info=None, description:str = None ):
        if not exception_info is None:
            logging.getLogger('RemotePluginEngine').exception(exception_info[1])
        super().set_full_status(state, exception_info, description)
        
    def _query_failed(self, e:Exception):
        #topology builder should be empty before next query
        self.topology_builder.set_clear_after_flush(True)
        self.topology_builder.flush_result()
        super()._query_failed(e)
        
    def __repr__(self):
        return "<RemotePluginEngine, meta_name:%s id:%s>" % (self.metadata["name"], hex(id(self)))
