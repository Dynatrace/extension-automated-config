"""
Defines the base class for other plugins to use.
"""
from logging import Logger
from typing import Dict, Any, List
from .exceptions import ConfigException
from .results_builder import ResultsBuilder
from .topology_builder import TopologyBuilder
from ..utils.select_helper import check_snapshot_entry
from ..package_utils.plugin_updater import PluginInfo
import ruxit.select_plugins
from .selectors import EntityType
from ruxit.api.data import MEAttribute
from typing import NamedTuple

class ExternalFunctions(NamedTuple):
    agent_version: str


class ProcessInfo(NamedTuple):
    pid: str
    """
    Pid of the process
    :return: srt
    """
    name: str
    """
    Name of the process
    :return: str
    """
    properties: Dict[str, str]
    """
    Additional information on the process in the form of a dictionary. Possible keys include:
    WorkDir - working directory of the process
    CmdLine - command line of the process
    PortBindings - TCP port binding data. Use snapshot.parse_port_bindings() to receive parsed data. The parsed data is list of 2 element tuple. The first field is a binded IP address (string) and the second field is a port (integer). 0.0.0.0 bind address is converted to local host address 127.0.0.1.
    ListeningPorts - ports on which the process is listening in the form of a space-separated string. This is deprecated, so please use PortBindings.
    :return: Dictionary of a pair of strings
    """

    def __repr__(self):
        return f"{type(self).__name__}(pid={self.pid}, process name={self.name}, properties={self.properties})"

    def __eq__(self, other):
        if not isinstance(other, ProcessInfo):
            return NotImplemented

        return self.pid == other.pid and self.name == other.name and self.properties == other.properties


class ProcessGroupInstance(NamedTuple):
    """
    Contains information about a single process group. It contains the entity of the group that should be used to report measurements associated with processes in the group.
    """
    group_id: str
    """
    Group ID of the snapshot entry. A process group is a set of processes that perform the same function across multiple hosts. For example, you might have a cluster of servers with each server running the same process in support of multiple hosts.
    :return: str
    """
    node_id: str
    group_instance_id: str
    """
    Process group instance is the ID of a group of processes that perform the same task on a given host. Process group instance ID is a unique identifier in your environment, and thus should be used to report associated data.
    :return: str
    """
    process_type: str
    group_name: str
    """
    Name of the process group. This is assigned in a manner specific to each process type.
    :return: str
    """
    processes: List[ProcessInfo]
    """
    Processes assigned to this process group. An iterable of ProcessInfo instances.
    :return: list of ProcessInfo
    """
    properties: Dict[str, str]
    """
    Additional information on the process in the form of a dictionary. Possible keys include: CmdLine, WorkDIr, ListeningPorts.
    :return: Dictionary of a pair of strings.
    """

    def __repr__(self):
        return f"{type(self).__name__}(group ID={self.group_id}, node ID={self.node_id}, process technologies={self.technologies}, group instance ID={self.group_instance_id}, group name={self.group_name}, processes details={self.processes}, properties={self.properties})"

    def __eq__(self, other):
        if not isinstance(other, ProcessGroupInstance):
            return NotImplemented

        return self.group_id == other.group_id and \
            self.node_id == other.node_id and \
            self.process_type == other.process_type and \
            self.group_instance_id == other.group_instance_id and \
            self.group_name == other.group_name and \
            self.processes == other.processes and \
            self.properties == other.properties and \
            self.technologies == other.technologies

    @property
    def technologies(self) -> str:
        """
        Technologies recognized for the process, often used for plugin activation. Please refer to Plugin.json reference for the full list of available technologies.
        :return: List of strings.
        """
        return self.properties.get("Technologies", None)

class MonitoredEntity:
    """
    MonitoredEntity class for plugins.
    """
    def __init__(self, result_builder, id, type, snapshot):
        self._result_builder = result_builder
        self._id = id
        self._type = type
        self._snapshot = snapshot

    @property
    def id(self) -> str:
        """
        The identifier of the monitored entity.
        :return: str
        """
        return self._id

    @property
    def type(self) -> EntityType:
        """
        The type of the monitored entity. Possible values: EntityType.HOST, EntityType.PROCESS_GROUP_INSTANCE, EntityType.PROCESS_GROUP
        :return:
        """
        return self._type

    @property
    def snapshot(self) -> List[ProcessGroupInstance]:
        """
        Process snapshot containing all processes related to the activation context.
        :return: List of ProcessGroupInstance
        """
        return self._snapshot

    @property
    def process_name(self) -> str:
        """
        Name of the process group. This is assigned in a manner specific to each process type.
        :return:
        """
        return self._snapshot[0].group_name


    def absolute(self, key, value, dimensions=None):
        """
        Adds an absolute results. Absolute results are sent unmodified - no additional calculations are performed.

        :param key: metric key.
        :param value: metric value
        :param dimensions: optional dictionary of 2 strings {'key', 'value'}
        """
        _plugin_measurement = self._result_builder._createpm(key=key, value=value, dimensions=dimensions, entity_id=self.id, entity_type=self.type)
        self._result_builder.add_absolute_result(_plugin_measurement)

    def relative(self, key, value, dimensions=None):
        """
        Adds a relative result. Use for metrics that increase monotonically (such as counters) After gathering the second result,
        the difference between the current and previous results is sent to the server (if it is non-negative). If there is a
        negative difference between measurements, nothing is sent.

        :param key: metric key.
        :param value: metric value
        :param dimensions: optional dictionary of two strings {'key', 'value'}
        """
        _plugin_measurement = self._result_builder._createpm(key=key, value=value, dimensions=dimensions, entity_id=self.id, entity_type=self.type)
        self._result_builder.add_relative_result(_plugin_measurement)

    def per_second(self, key, value, dimensions=None):
        """
        Adds per second result. Use for metrics that increase monotonically (such as counters) After gathering the second result,
        the difference between the current and previous results is sent to the server (if it is non-negative). It will be
        divided by the time difference between measurements in seconds, resulting in a per-second rate. If there is a
        negative difference between the measurements, nothing is sent.

        :param key: metric key.
        :param value: metric value
        :param dimensions: optional dictionary of two strings {'key', 'value'}

        """
        _plugin_measurement = self._result_builder._createpm(key=key, value=value, dimensions=dimensions,
                                                             entity_id=self.id, entity_type=self.type)
        self._result_builder.add_per_second_result(_plugin_measurement)

    def state_metric(self, key, value,  dimensions=None):
        """
        Adds state metric. :class:`~ruxit.api.data.PluginStateMetric` object is constructed implicitly in the method.

        :param key: key of the measurement. Must be a string.
        :param value: value of the measurement. Must be convertible to float.
        :param dimensions: dimensions of the measurement. A Dictionary with string keys and string values.
        """
        _plugin_state_metric = self._result_builder._createpsm(key=key, value=value, dimensions=dimensions,
                                                             entity_id=self.id, entity_type=self.type)
        self._result_builder.add_absolute_result(_plugin_state_metric)

    def property(self, key, value):
        """
        Adds entity property. PluginProperty object is constructed implicitly in the method.

        :param key: key of the measurement. Must be a string.
        :param value: value of the measurement. Must be convertible to float.
        """
        if self.type == EntityType.HOST:
            me_attribute = MEAttribute.CUSTOM_HOST_METADATA
        else:
            me_attribute = MEAttribute.CUSTOM_PG_METADATA
        self._result_builder.report_property(key=key, value=value, entity_id=self.id, entity_type=self.type, me_attribute=me_attribute)

    def event_performance(self, description: str = None, title: str = None,
                                 properties: Dict[str, str] = {}):
        """
        Reports a performance event.

        :param description: default None, Event description as string of max 10240 characters long.
        :param title: Event title as string of max 1024 characters long.
        :param properties: Event properties as dictionary of 2 strings. Max key length is 100 characters, max value length is 1000 characters. Max number of elements in the dictionary is 100.
        """
        entity_selector = self._result_builder._resolve_entity_selector(self.id, self.type, None)
        self._result_builder.report_performance_event(description=description, title=title, properties=properties, entity_selector=entity_selector)

    def event_error(self, description: str = None, title: str = None,
                                 properties: Dict[str, str] = {}):
        """
        Reports an error event.

        :param description: default None, Event description as string of max 10240 characters long.
        :param title: Event title as string of max 1024 characters long.
        :param properties: Event properties as dictionary of 2 strings. Max key length is 100 characters, max value length is 1000 characters. Max number of elements in the dictionary is 100.
        """
        entity_selector = self._result_builder._resolve_entity_selector(self.id, self.type, None)
        self._result_builder.report_error_event(description=description, title=title, properties=properties, entity_selector=entity_selector)

    def event_availability(self, description: str = None, title: str = None,
                                 properties: Dict[str, str] = {}):
        """
        Reports an availability event.

        :param description: default None, Event description as string of max 10240 characters long.
        :param title: Event title as string of max 1024 characters long.
        :param properties: Event properties as dictionary of 2 strings. Max key length is 100 characters, max value length is 1000 characters. Max number of elements in the dictionary is 100.
        """
        entity_selector = self._result_builder._resolve_entity_selector(self.id, self.type, None)
        self._result_builder.report_availability_event(description=description, title=title, properties=properties, entity_selector=entity_selector)

    def event_resource_contention(self, description: str = None, title: str = None,
                                 properties: Dict[str, str] = {}):
        """
        Reports a resource contention event.

        :param description: default None, Event description as string of max 10240 characters long.
        :param title: Event title as string of max 1024 characters long.
        :param properties: Event properties as dictionary of 2 strings. Max key length is 100 characters, max value length is 1000 characters. Max number of elements in the dictionary is 100.
        """
        entity_selector = self._result_builder._resolve_entity_selector(self.id, self.type, None)
        self._result_builder.report_resource_contention_event(description=description, title=title, properties=properties, entity_selector=entity_selector)

    def event_custom_info(self, description: str = None, title: str = None,
                                 properties: Dict[str, str] = {}):
        """
        Reports a custom info event.

        :param description: default None, Event description as string of max 10240 characters long.
        :param title: Event title as string of max 1024 characters long.
        :param properties: Event properties as dictionary of 2 strings. Max key length is 100 characters, max value length is 1000 characters. Max number of elements in the dictionary is 100.
        """
        entity_selector = self._result_builder._resolve_entity_selector(self.id, self.type, None)
        self._result_builder.report_custom_info_event(description=description, title=title, properties=properties, entity_selector=entity_selector)

    def event_custom_deployment(self, source: str = None,
                                       project: str = None,
                                       version: str = None,
                                       ci_link: str = None,
                                       remediation_action_link: str = None,
                                       deployment_name: str = None,
                                       properties: Dict[str, str] = {},):
        """
        Reports a custom deployment event.

        :param source: Event source as string of max 10240 characters long.
        :param project: Event project as string of max 10240 characters long.
        :param version: Event version as string of max 10240 characters long.
        :param ci_link: Event link as string of max 10240 characters long.
        :param remediation_action_link: Event remediation action link as string of max 10240 characters long.
        :param deployment_name: Event deployment name as string of max 10240 characters long.
        :param properties: Event properties as dictionary of 2 strings. Max key length is 100 characters, max value length is 1000 characters. Max number of elements in the dictionary is 100.
        """
        entity_selector = self._result_builder._resolve_entity_selector(self.id, self.type, None)
        self._result_builder.report_custom_deployment_event(source=source, project=project, version=version, ci_link=ci_link, remediation_action_link=remediation_action_link, deployment_name=deployment_name, properties=properties, entity_selector=entity_selector)

    def event_custom_annotation(self, description: str = None,
                                       annotation_type: str = None,
                                       source: str = None,
                                       properties: Dict[str, str] = {}):
        """
        Reports a custom annotation event.

        :param description: Event description as string of max 10240 characters long.
        :param annotation_type: Event annotation_type as string of max 10240 characters long.
        :param source: Event source as string of max 10240 characters long.
        :param properties: Event properties as dictionary of 2 strings. Max key length is 100 characters, max value length is 1000 characters. Max number of elements in the dictionary is 100.
        """
        entity_selector = self._result_builder._resolve_entity_selector(self.id, self.type, None)
        self._result_builder.report_custom_annotation_event(description=description, annotation_type=annotation_type, source=source, properties=properties, entity_selector=entity_selector)


class MonitoredEntities:
    """
    MonitoredEntities class for plugins provides the list of MonitoredEntity objects related to the activation context.
    Each MonitoredEntity contains such properties as: ID, type, snapshot and all the methods for sending plugin data.
    """

    def __init__(self, result_builder, activation_context, plugin_info):
        #self._me = activation_context.meid
        self._result_builder = result_builder
        self._activation_context = activation_context
        self._plugin_info = plugin_info
        #self._snapshot_complete = snapshot_complete


    def _get_me_type_from_str(self, me_type_requested) -> EntityType:
        me_types_mapping = {
            "PROCESS_GROUP_INSTANCE": ruxit.select_plugins.selectors.EntityType.PROCESS_GROUP_INSTANCE,
            "PROCESS_GROUP": ruxit.select_plugins.selectors.EntityType.PROCESS_GROUP,
            "HOST": ruxit.select_plugins.selectors.EntityType.HOST
        }
        if me_type_requested not in me_types_mapping.keys():
            raise ValueError("Unknown monitored entity type")

        return me_types_mapping[me_type_requested]


    def get(self, snapshot_complete, me_type:EntityType = None) -> List[MonitoredEntity]:
        plugin_info = self._plugin_info
        assoc_process_types = plugin_info.process_types
        assoc_technologies = plugin_info.technologies
        name_pattern = plugin_info.name_pattern
        #get the snapshot with processess related to activation context
        if snapshot_complete is None:
            return []
        snapshot_pse = ruxit.select_plugins.ProcessTypeSingletonActivationContext.get_snapshot(assoc_process_types,
                                                                                    assoc_technologies,
                                                                                    name_pattern,
                                                                                    snapshot_complete)
        #convert snapshot as _ProcessSnapshotEntry to ProcessGroupInstance object
        snapshot = []
        for entry in snapshot_pse:
            processes_object_list = []
            for proc in entry.processes:
                processes_object = ProcessInfo(proc.pid, proc.process_name, proc.properties)
                processes_object_list.append(processes_object)
            snapshot.append(ProcessGroupInstance(entry.group_id, entry.node_id, entry.group_instance_id, entry.process_type, entry.group_name, processes_object_list, entry.properties))

        #if me_type not provided get me_type from activation context
        if me_type == None:
            me_type = self._get_me_type_from_str(self._plugin_info.json_data.get("entity", "PROCESS_GROUP_INSTANCE"))

        if me_type not in EntityType:
            raise ValueError("Unknown monitored entity type:", me_type)

        if me_type == EntityType.HOST:
            host_id = snapshot_complete.host_id if snapshot_complete.host_id else None
            me_host = [MonitoredEntity(self._result_builder, host_id, ruxit.select_plugins.selectors.EntityType.HOST,
                                       snapshot=snapshot)]  # consider giving complete snapshot here
            return me_host

        if me_type == EntityType.PROCESS_GROUP:
            return self._build_me_group(snapshot)

        me_process = []
        for entry in snapshot:
            me_process.append(
                MonitoredEntity(self._result_builder, id=entry.group_instance_id, type=EntityType.PROCESS_GROUP_INSTANCE, snapshot=[entry]))
        return me_process

    def _build_me_group(self, snapshot):
        me_group = {}
        for entry in snapshot:
            #check if already added - group processes belonging to the same group into single Monitored Entity
            if entry.group_id in me_group:
                me_group[entry.group_id].snapshot.append(entry)
            else:
                me_group[entry.group_id] = MonitoredEntity(self._result_builder, id=entry.group_id, type=EntityType.PROCESS_GROUP,
                                            snapshot=[entry])
        return [l for l in me_group.values()]

class BasePlugin():
    """
    Base class for plugins.
    """
    AgentVersion = NamedTuple('AgentVersion', [('major', int), ('minor', int), ('revision', int), ('build', str)])
    def __init__(self, **kwargs):
        """
        __init__ should not be overridden without a call to super.

        :param config: :class:`~Dict[str, str]` plugin configuration
        :param results_builder: :class:`~ruxit.api.results_builder.ResultsBuilder` instance for this plugin
        :param json_config: parsed plugin.json contents
        :param plugin_info: :class:`ruxit.package_utils.plugin_updater.PluginInfo` json data of the plugin exposed in a more convenient way
        :param associated_entity: monitored entity associated with the plugin, if any (deprecated)
        :param activation_context: activation context for the plugin
        :param process_snapshot: :class:`ProcessSnapshot` latest available at method call
        :param entity_resolver: :class:`ruxit.entity_resolver.EntityResolver`  exposes additional methods for querying snapshot
        :param logger: plugin: specific logger for plugin development, set to None only in unit tests
        """
        self.plugin_info: PluginInfo = kwargs.get('plugin_info', None)
        self.results_builder: ResultsBuilder = kwargs['results_builder']
        self.query_snapshot = kwargs.get('process_snapshot', None)
        self.logger: Logger = kwargs.get('logger', None)
        self.config: Dict[str, Any] = kwargs.get('config',{})
        self.activation = kwargs.get('activation_context', None)
        kwargs['config'] = self._get_raw_config()
        self.monitored_entities = MonitoredEntities(self.results_builder, self.activation, self.plugin_info)
        self._functions:ExternalFunctions = kwargs.get('functions')
        self._agent_version = self._get_agent_version()
        self.initialize(**kwargs)

    @property
    def agent_version(self) -> AgentVersion:
        """
            :return: Agent version as AgentVersion = NamedTuple('AgentVersion', [('major', int), ('minor', int), ('revision', int), ('build', str)])
        """
        return self._agent_version

    #get not parsed configuration (only for local plugins)
    def _get_raw_config(self):
        tmp_cfg = {}
        for name, value in self.config.items():
            value_type = type(value)
            if value_type == bool:
                tmp_cfg[name] = 'true' if value else 'false'
            elif value_type == str:
                tmp_cfg[name] = value
            else:
                tmp_cfg[name] = str(value)
        return tmp_cfg

    def initialize(self, **kwargs):
        """
        Abstract method for custom plugin initialization.
        Called after __init__. Override if additional initialization
        (for example, acquiring connections once instead of on every query method execution) is needed.

        :param \**kwargs: see :class:`BasePlugin` for keyword args reference
        """
        pass

    def _query_internal(self, **kwargs):
        self.query_snapshot = kwargs.get('process_snapshot', None)
        return self.query(**kwargs)

    def query(self, **kwargs):
        """
        Abstract method called to gather measurements. Every plugin should override this method.

        :param \**kwargs: see :class:`BasePlugin` for keyword args reference
        """
        pass

    def close(self, **kwargs):
        """
        Abstract method called when plugin is deactivated.

        :param \**kwargs: see :class:`BasePlugin` for keyword args reference
        """
        pass

    def find_all_process_groups(self, predicate):
        """
        Searches the latest process snapshot for all process groups matching the predicate

        :param predicate: One parameter function returning bool if snapshot entry meets predicate conditions
        :return: list of process snapshot entries

        """
        return [entry for entry in self.query_snapshot.entries if predicate(entry)]

    def find_single_process_group(self, predicate):
        """
        Searches the latest process snapshot for a process group matching the predicate

        :param predicate: One parameter function returning bool if snapshot entry meets predicate conditions
        :return: list of process snapshot entries
        """
        ret = [entry for entry in self.query_snapshot.entries if predicate(entry)]
        if len(ret) != 1:
            raise ConfigException("Expected exactly 1 pgi to match predicate found: %s" % len(ret))
        return ret[0]

    def find_all_processes(self, process_predicate):
        """
        Searches the latest process snapshot for a process and associated process group that match the criteria passed
        in arguments. Only processes of types associated with plugin are searched.

        :param process_predicate: one parameter function which takes process info as input and returns bool
        :return: list of tuple(PGI, process) that matched predicate
        """
        return self._internal_find_process(process_predicate)

    def find_single_process(self, process_predicate):
        """
        Searches the latest process snapshot for a process and associated process group that match the criteria passed
        in arguments. If more than one process matching the criteria is found, an exception is raised.
        Only processes of types associated with plugin are searched.

        :param process_predicate: one parameter function which takes process info as input and returns bool
        :raises: :class:`ConfigException`: if not exactly 1 matching process found
        :return: tuple(PGI, process)
        """
        ret = self._internal_find_process(process_predicate)
        _ln = len(ret)
        if _ln != 1:
            raise ConfigException("Expected exactly 1 process matching predicate, found: %s" % _ln)
        return ret[0]

    def _internal_find_process(self, process_predicate):
        assoc_process_types = self.plugin_info.associated_process_types
        assoc_technologies = self.plugin_info.associated_technologies
        name_pattern = self.plugin_info.name_pattern
        def pgi_predicate(entry):
            return check_snapshot_entry (entry, assoc_process_types, assoc_technologies, name_pattern)

        ret = self._find_process_and_pgi(
            self.query_snapshot,
            pgi_predicate=pgi_predicate,
            process_predicate=process_predicate
        )
        return ret

    def _find_process_and_pgi(self, snapshot, pgi_predicate, process_predicate):
        entries = (entry for entry in snapshot.entries if pgi_predicate(entry))
        return self._find_process(entries, process_predicate)

    def _find_process(self, entries, process_predicate):
        return [(pgi, process) for pgi in entries for process in pgi.processes if process_predicate(process)]

    def get_monitored_entities(self, me_type=None) -> List[MonitoredEntity]:
        """
        Gets the list of MonitoredEntities related to the plugin based on the entity type defined in plugin.json or given type as argument.
        By default, the type is taken from plugin.json - entity field.
        If a type other than the type defined in the entity field is required, the me_type must be given as an argument.
        A typical example is the plugin reporting most data on the process group instance level, where the entity is PROCESS_GROUP_INSTANCE, but some metrics are on the process group (cluster) level.
        Then the me_type PROCESS_GROUP should be given as an argument and the corresponding group ID will be returned.

        :param me_type: optional monitored entity type. One of: process, group, host
        :return: MonitoredEntity object containing: id, type, snapshot_entry
        """
        return  self.monitored_entities.get(self.query_snapshot, me_type)

    def get_activation_type(self):
        """
        DT_IGNORE
        :return:
        """
        return type(self.activation.value)

    def get_activation_context(self):
        """
        DT_IGNORE
        :return:
        """
        return self.activation

    def _get_agent_version(self) -> AgentVersion:
        version = self.AgentVersion(0, 0, 0, "")
        if self._functions:
            if self._functions.agent_version:
                    version_str = self._functions.agent_version
                    ver_slices = version_str.split('.')
                    if len(ver_slices) == 4:
                        version = self.AgentVersion(int(ver_slices[0]), int(ver_slices[1]), int(ver_slices[2]), ver_slices[3])
        return version


class RemoteBasePlugin(BasePlugin):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.topology_builder: TopologyBuilder = kwargs['topology_builder']

    #remote plugin has always parsed configuration
    def _get_raw_config(self):
        return self.config
