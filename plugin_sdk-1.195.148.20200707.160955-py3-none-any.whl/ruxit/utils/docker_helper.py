import sys
import os.path
import docker
from urllib import parse
from socket import timeout, SHUT_RDWR
import tarfile
from io import BytesIO
import inspect


class DockerUtils:

    def __init__(self):
        pass

    @staticmethod
    def get_docker_file_path(process_info_properties: dict, file_path: str):
        if sys.platform == 'win32':
            return file_path
        else:
            return DockerUtils.get_linux_file_path(process_info_properties["DockerContainerId"], file_path)

    @staticmethod
    def get_docker_external_port(process_info_properties: dict, port_number: int):
        try:
            client = docker.APIClient(version='auto')
            if client.inspect_container(process_info_properties["DockerContainerId"]).get("HostConfig", {}).get("NetworkMode", "bridge") == "host":
                return port_number
            return client.port(process_info_properties["DockerContainerId"], port_number)[0]["HostPort"]
        except:
            return port_number

    @staticmethod
    def replace_port_with_exposed_by_docker(process_info_properties: dict, url):
        parsed_url = parse.urlparse(url)
        docker_port = DockerUtils.get_docker_external_port(process_info_properties, str(parsed_url.port))
        return parsed_url._replace(netloc=parsed_url.netloc.replace(str(parsed_url.port), docker_port)).geturl()

    @staticmethod
    def get_linux_file_path(container_id: str, file_path: str):
        file_path = os.path.normcase(file_path)
        return file_path

    @staticmethod
    def file_wrapper(process_info_properties: dict, file_path: str):
        file_path = os.path.normcase(file_path)
        client = docker.APIClient(version='auto')
        eid = client.exec_create(process_info_properties["DockerContainerId"], "/bin/cat {fp}".format(fp=file_path))
        output = client.exec_start(exec_id = eid["Id"])
        return FileWrapper(output.decode("utf-8").strip())

    @staticmethod
    def docker_process(process_info_properties: dict):
        return DockerProcess(process_info_properties["DockerContainerId"])

    @staticmethod
    def instrument_container(process_info_properties: dict):
        def get_agent_folder(path: str):
            head, tail = os.path.split(path)
            if tail == "agent":
                return path
            else:
                return get_agent_folder(head)
        client = docker.APIClient(version='auto')

        my_path = inspect.stack()[0][1]
        agent_path = get_agent_folder(my_path)
        helper_file = os.path.join(agent_path, "lib64", "pluginsdockerutil")
        helper_data = open(helper_file, "rb").read()

        pw_tarstream = BytesIO()
        pw_tar = tarfile.TarFile(fileobj=pw_tarstream, mode='w')

        tarinfo = tarfile.TarInfo(name="pluginsdockerutil")
        tarinfo.size = len(helper_data)
        tarinfo.mode = 0o700
        pw_tar.addfile(tarinfo, BytesIO(helper_data))
        pw_tar.close()
        pw_tarstream.seek(0)

        client.put_archive(process_info_properties["DockerContainerId"], "/", pw_tarstream)


    @staticmethod
    def message_socket(process_info_properties: dict, socket_path: str, message: str):
        client = docker.APIClient(version='auto')
        eid = client.exec_create(process_info_properties["DockerContainerId"], "/pluginsdockerutil socketProxy -p {p} -m \"{m}\"".format(p=socket_path, m=message))
        output = client.exec_start(exec_id = eid["Id"])
        return FileWrapper(output.decode("utf-8").strip())


class FileWrapper:
    def __init__(self, file_content):
        self.file_lines = file_content.splitlines()

    def __enter__(self):
        pass

    def __exit__(self, type, value, traceback):
        pass

    def __iter__(self):
        for line in self.file_lines:
            yield line


class DockerProcess:
    def __init__(self, container_id: str):
        self.client = docker.APIClient(version='auto')
        self.container_id = container_id
        self.open_connection()

    def __del__(self):
        try:
            self.close_connection()
        finally:
            pass

    def close_connection(self):
        try:
            if self.exec_socket is not None:
                self.exec_socket._sock.shutdown(SHUT_RDWR)
                self.exec_socket._sock.close()
        finally:
            self.exec_socket = None
            self.instance = None
            pass

    def open_connection(self):
        self.instance = self.client.exec_create(container=self.container_id, cmd="/bin/bash", stdin=True)
        self.exec_socket = self.client.exec_start(exec_id=self.instance["Id"], socket=True)
        self.exec_socket._sock.setblocking(0)
        self.exec_socket._sock.settimeout(1)

    def reset_connection(self):
        self.close_connection()
        self.open_connection()

    def execute_command(self, command):
        self.exec_socket._sock.send((command + os.linesep).encode())
        self.exec_socket.flush()

    """
    This method returns console output of what was provided as input
    """
    def run(self, command: str) -> str:
        try:
            self.execute_command(command)
        except BrokenPipeError:
            self.reset_connection()
            self.execute_command(command)

        ret = ''
        try:
            while True:
                buf = self.exec_socket._sock.recv(1024).decode("latin-1")
                if buf == '':
                    return ret
                ret = ret + buf
        except timeout:
            return ret


